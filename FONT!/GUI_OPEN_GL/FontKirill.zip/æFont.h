#pragma once
#include <stdint.h> //uint32_t
#include <ft2build.h>
#include <freetype/freetype.h>
#include <freetype/ftglyph.h>
#include <freetype/ftoutln.h>
#include <freetype/fttrigon.h>
#include <windows.h>
#include <gl/GLU.h>
#include <string.h>

#define FONT_TOTAL_GLYPHS 128
#define FONT_RESOLUTION 96

class CColor4 {
public:
	CColor4(uint8_t rr, uint8_t gg, uint8_t bb, uint8_t aa) : r(rr), g(gg), b(bb), a(aa) {}
	~CColor4() {}

	uint8_t r, g, b, a;
};

struct TEXTSIZE {
	int width, height;
};

enum font_creating_errors_e {
	FONT_OK,
	FONT_ERROR_ALLOCATE_MEMORY,
	FONT_ERROR_INITIALIZING,
	FONT_ERROR_LOAD
};

class �Font
{
	int m_iFontSize;
	int m_iLastLineWidth;
	int m_iLastLineHeight;
	float m_fTextScale;
	uint32_t *m_pGlyphTextures;
	uint32_t m_ListIds;
	struct glyph_size_s {
		int width, height;
	} *m_pGlypsSizes;

	inline int NextP2(int iNext)
	{
		int iRVal = 1;
		// rval<<=1 Is A Prettier Way Of Writing rval*=2; 
		while (iRVal < iNext) iRVal <<= 1;
		return iRVal;
	}

public:
	�Font() {}
	~�Font() {}

	int Init(const char *fontname, int font_size) {
		m_fTextScale = 1.0f;
		m_iFontSize = font_size;
		m_pGlyphTextures = (uint32_t *)malloc(FONT_TOTAL_GLYPHS * sizeof(uint32_t));
		if (!m_pGlyphTextures)
			return FONT_ERROR_ALLOCATE_MEMORY;

		m_pGlypsSizes = (glyph_size_s *)malloc(FONT_TOTAL_GLYPHS * sizeof(glyph_size_s));
		if (!m_pGlypsSizes) {
			free(m_pGlyphTextures);
			return FONT_ERROR_ALLOCATE_MEMORY;
		}

		// Create And Initilize A FreeType Font Library.
		FT_Library library;
		FT_Error ftError = FT_Init_FreeType(&library);
		if (ftError != 0)
			return FONT_ERROR_INITIALIZING;

		// The Object In Which FreeType Holds Information On A Given
		// Font Is Called A "face".
		FT_Face face;

		// This Is Where We Load In The Font Information From The File.
		// Of All The Places Where The Code Might Die, This Is The Most Likely,
		// As FT_New_Face Will Fail If The Font File Does Not Exist Or Is Somehow Broken.
		ftError = FT_New_Face(library, fontname, 0, &face);
		if (ftError != 0)
			return FONT_ERROR_LOAD;

		// For Some Twisted Reason, FreeType Measures Font Size
		// In Terms Of 1/64ths Of Pixels.  Thus, To Make A Font
		// h Pixels High, We Need To Request A Size Of h*64.
		// (h << 6 Is Just A Prettier Way Of Writing h*64)
		FT_Set_Char_Size(face, m_iFontSize << 6, m_iFontSize << 6, FONT_RESOLUTION, FONT_RESOLUTION);

		// Here We Ask OpenGL To Allocate Resources For
		// All The Textures And Display Lists Which We
		// Are About To Create.  
		m_ListIds = (uint32_t)glGenLists(FONT_TOTAL_GLYPHS);
		glGenTextures(FONT_TOTAL_GLYPHS, m_pGlyphTextures);

		// This Is Where We Actually Create Each Of The Fonts Display Lists.
		for (unsigned char i = 0; i < 128; i++) {
			FT_Error ftError = FT_Load_Glyph(face, FT_Get_Char_Index(face, i), FT_LOAD_DEFAULT);

			FT_Glyph ftGlyph;
			ftError = FT_Get_Glyph(face->glyph, &ftGlyph);

			// Convert The Glyph To A Bitmap.
			FT_Glyph_To_Bitmap(&ftGlyph, ft_render_mode_normal, 0, 1);
			FT_BitmapGlyph ftBitmapGlyph = (FT_BitmapGlyph)ftGlyph;

			// This Reference Will Make Accessing The Bitmap Easier.
			FT_Bitmap& ftBitmap = ftBitmapGlyph->bitmap;

			// Use Our Helper Function To Get The Widths Of
			// The Bitmap Data That We Will Need In Order To Create
			// Our Texture.
			int iWidth = NextP2(ftBitmap.width);
			int iHeight = NextP2(ftBitmap.rows);

			// Allocate Memory For The Texture Data.
			uint8_t *pExpandedData = (uint8_t *)malloc(sizeof(uint8_t) * 2 * iWidth * iHeight);

			// Here We Fill In The Data For The Expanded Bitmap.
			// Notice That We Are Using A Two Channel Bitmap (One For
			// Channel Luminosity And One For Alpha), But We Assign
			// Both Luminosity And Alpha To The Value That We
			// Find In The FreeType Bitmap. 
			// We Use The ?: Operator To Say That Value Which We Use
			// Will Be 0 If We Are In The Padding Zone, And Whatever
			// Is The FreeType Bitmap Otherwise.
			for (int j = 0; j < iHeight; j++) {
				for (int i = 0; i < iWidth; i++) {
					pExpandedData[2 * (i + j * iWidth)] = pExpandedData[2 * (i + j * iWidth) + 1] = (i >= ftBitmap.width || j >= ftBitmap.rows) ? 0 : ftBitmap.buffer[i + ftBitmap.width*j];
				}
			}

			// Now We Just Setup Some Texture Parameters.
			glBindTexture(GL_TEXTURE_2D, m_pGlyphTextures[i]);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

			// Here We Actually Create The Texture Itself, Notice
			// That We Are Using GL_LUMINANCE_ALPHA To Indicate That
			// We Are Using 2 Channel Data.
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, iWidth, iHeight, 0, GL_LUMINANCE_ALPHA, GL_UNSIGNED_BYTE, pExpandedData);

			// With The Texture Created, We Don't Need The Expanded Data Anymore.
			free(pExpandedData);

			// Now We Create The Display List
			glNewList((uint32_t)m_ListIds + i, GL_COMPILE);
			{
				glBindTexture(GL_TEXTURE_2D, m_pGlyphTextures[i]);
				glPushMatrix();

				// First We Need To Move Over A Little So That
				// The Character Has The Right Amount Of Space
				// Between It And The One Before It.
				glTranslatef((float)ftBitmapGlyph->left, 0, 0);

				// Now We Move Down A Little In The Case That The
				// Bitmap Extends Past The Bottom Of The Line 
				// This Is Only True For Characters Like 'g' Or 'y'.

				// KC - Changed to work with the code change listed below.
				// 
				glTranslatef(0, (float)(-(ftBitmapGlyph->top - ftBitmap.rows)), 0);

				// Now We Need To Account For The Fact That Many Of
				// Our Textures Are Filled With Empty Padding Space.
				// We Figure What Portion Of The Texture Is Used By 
				// The Actual Character And Store That Information In
				// The x And y Variables, Then When We Draw The
				// Quad, We Will Only Reference The Parts Of The Texture
				// That Contains The Character Itself.
				float x = (float)ftBitmap.width / (float)iWidth;
				float y = (float)ftBitmap.rows / (float)iHeight;
				m_pGlypsSizes[i].width = ftBitmap.width;
				m_pGlypsSizes[i].height = ftBitmap.rows;

				//TODO: MAX GLYPH SIZE IN PIXELS
				//if (ftBitmap.width > *puiMaxPixelWidth)
				//{
				//	*puiMaxPixelWidth = ftBitmap.width;
				//}

				//if (static_cast<uint32>(ftBitmap.rows) > *puiMaxPixelHeight)
				//{
				//	*puiMaxPixelHeight = ftBitmap.rows;
				//}

				// Here We Draw The Texturemapped Quads.
				// The Bitmap That We Got From FreeType Was Not 
				// Oriented Quite Like We Would Like It To Be,
				// But We Link The Texture To The Quad
				// In Such A Way That The Result Will Be Properly Aligned.

				// KC - I changed the following code so that it creates
				// the quads as if the coordinate system is beggning at 0,0 being the
				// top left hand corner and moving down the window is increasing the the positive
				// y axis. For this reason the extens of the quad are created with negative Y components.
				//
				//
				glBegin(GL_QUADS);
				{
					glTexCoord2f(0, 0); //Bottom left hand corner.
					glVertex2i(0, -ftBitmap.rows);

					glTexCoord2f(0, y); //Top left
					glVertex2i(0, 0);

					glTexCoord2f(x, y); //Right  Top
					glVertex2i(ftBitmap.width, 0);

					glTexCoord2f(x, 0); //Right bottom
					glVertex2i(ftBitmap.width, -ftBitmap.rows);
				}
				glEnd();
				glPopMatrix();
				glTranslatef((float)(face->glyph->advance.x >> 6), 0, 0);

				m_pGlypsSizes[i].width = (int32_t)(face->glyph->advance.x >> 6);
				// Increment The Raster Position As If We Were A Bitmap Font.
				// (Only Needed If You Want To Calculate Text Length)
				// glBitmap(0,0,0,0,face->glyph->advance.x >> 6,0,NULL);
			}
			glEndList(); // Finish The Display List
		}

		// We Don't Need The Face Information Now That The Display
		// Lists Have Been Created, So We Free The Associated Resources.
		FT_Done_Face(face);

		// Ditto For The Font Library.
		FT_Done_FreeType(library);
	}

	__forceinline void ScaleFont(float scale) { m_fTextScale = scale; }
	__forceinline int GetTextWidth() { return m_iLastLineWidth; }
	__forceinline int GetTextHeight() { return m_iLastLineHeight; }

	/**
	* Get last text block size
	*/
	void GetTextExtentsPoints(TEXTSIZE *psize) {
		psize->width = m_iLastLineWidth;
		psize->height = m_iLastLineHeight;
	}

	void FreeFont() {
		glDeleteLists(m_ListIds, FONT_TOTAL_GLYPHS);
		glDeleteTextures(FONT_TOTAL_GLYPHS, m_pGlyphTextures);
		free(m_pGlyphTextures);
	}

	void RenderText(const char* strText, int x, int y, const CColor4 *rgbColor)
	{
		m_iLastLineWidth = 0;
		m_iLastLineHeight = 0;
		// We Make The Height A Little Bigger.  There Will Be Some Space Between Lines.
		float h = m_iFontSize / (float).63f;

		glPushAttrib(GL_LIST_BIT | GL_CURRENT_BIT | GL_ENABLE_BIT | GL_TRANSFORM_BIT);
		glMatrixMode(GL_MODELVIEW);
		glDisable(GL_LIGHTING);
		glEnable(GL_TEXTURE_2D);
		//glDisable(GL_DEPTH_TEST);
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

		glListBase(m_ListIds);

		float modelview_matrix[16];
		glGetFloatv(GL_MODELVIEW_MATRIX, modelview_matrix);

		// This Is Where The Text Display Actually Happens.
		// For Each Line Of Text We Reset The Modelview Matrix
		// So That The Line's Text Will Start In The Correct Position.
		// Notice That We Need To Reset The Matrix, Rather Than Just Translating
		// Down By h. This Is Because When Each Character Is
		// Drawn It Modifies The Current Matrix So That The Next Character
		// Will Be Drawn Immediately After It.  

		glColor4ubv((uint8_t *)rgbColor); //set the current color

		const int i = 1; //TODO: line offset to down! Fix this!

		glPushMatrix();
		glLoadIdentity();
		glTranslatef(x, y - h * i, 0);
		glScalef(m_fTextScale, m_fTextScale, 0.0f);
		glMultMatrixf(modelview_matrix);

		// The Commented Out Raster Position Stuff Can Be Useful If You Need To
		// Know The Length Of The Text That You Are Creating.
		// If You Decide To Use It Make Sure To Also Uncomment The glBitmap Command
		// In make_dlist().
		// glRasterPos2f(0,0);

		glCallLists(strlen(strText), GL_UNSIGNED_BYTE, strText);
		// float rpos[4];
		// glGetFloatv(GL_CURRENT_RASTER_POSITION ,rpos);
		// float len=x-rpos[0]; (Assuming No Rotations Have Happend)

		glPopMatrix();

		glPopAttrib();
		glDisable(GL_BLEND);
		glDisable(GL_TEXTURE_2D);

		///////////////////////////////////////////////////////////
		//TODO: ��������! ������ ������� ������
		m_iLastLineHeight = m_iFontSize;
		for (int i = 0; strText[i]; i++)
			m_iLastLineWidth += m_pGlypsSizes[i].width;
		///////////////////////////////////////////////////////////
	}

};

